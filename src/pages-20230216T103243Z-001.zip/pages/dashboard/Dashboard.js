import { AdminLayout } from "../layout/AdminLayout"

const Dashboard = () => {
  return <AdminLayout>Dashboard</AdminLayout>
}
export default Dashboard
