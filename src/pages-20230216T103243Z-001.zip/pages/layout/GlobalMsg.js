import React from "react";

export const GlobalMsg = () => {
  return <div>global message</div>;
};
