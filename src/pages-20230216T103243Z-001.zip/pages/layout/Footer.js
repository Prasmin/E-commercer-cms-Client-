import React from "react";

export const Footer = () => {
  return (
    <div className="bg-dark text-light p-5 text-center">
      &copy; Copy right all reserved. Made by <a href="#!">Prem Achary</a>
    </div>
  );
};
